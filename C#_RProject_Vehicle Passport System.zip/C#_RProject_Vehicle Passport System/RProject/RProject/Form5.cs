﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RProject
{
    public partial class Form5 : Form
    {
        string connectionString =
           "data source=DESKTOP-ELE0INQ\\SQLEXPRESS; database=V; integrated security=SSPI";

        int userId;
        int vehicleId;

        public Form5(int userId, int vehicleId)
        {
            InitializeComponent();

            this.userId = userId;
            this.vehicleId = vehicleId;

            // Automatically show IDs
            textBox1.Text = userId.ToString();
            textBox2.Text = vehicleId.ToString();

            // IDs cannot be changed
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;

            LoadVehicleData();
        }


        private void LoadVehicleData()
        {
            string query = "SELECT [Year], [Model], [RegistrationNum], " +
                "[RegistrationExpiry], [InsuranceExpiry], " +
                "[CurrentMileage], [FuelType] " +
                "FROM Vehicle " +
                "WHERE [VehicleID] = @VehicleID";

            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            {
                using (SqlCommand command =
                       new SqlCommand(query, connection))
                {
                    
                    command.Parameters.AddWithValue("@VehicleID", vehicleId);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            textBox4.Text = reader["Model"].ToString(); 
                            textBox3.Text = reader["RegistrationNum"].ToString(); 
                            
                            dateTimePicker1.Value = new DateTime(Convert.ToInt32(reader["Year"]), 1, 1); 
                            dateTimePicker2.Value = Convert.ToDateTime(reader["RegistrationExpiry"]); 
                            dateTimePicker3.Value = Convert.ToDateTime(reader["InsuranceExpiry"]);

                            textBox5.Text = reader["CurrentMileage"].ToString();
                            comboBox1.Text = reader["FuelType"].ToString();
                        }
                        else
                        {
                            MessageBox.Show(
                                "Vehicle information not found.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                            this.Close();
                        }
                    }
                }
            }
        }


        
        private void button3_Click(object sender, EventArgs e)
        {
            int year = dateTimePicker1.Value.Year;
            string model = textBox4.Text.Trim();
            string registrationNum = textBox3.Text.Trim();
            int currentMileage;

            if (!int.TryParse(textBox5.Text.Trim(), out currentMileage))
            {
                MessageBox.Show(
                    "Please enter a valid mileage number.",
                    "Invalid Mileage",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }
            string fuelType = comboBox1.Text;


            if (string.IsNullOrWhiteSpace(model) || string.IsNullOrWhiteSpace(registrationNum))
            {
                MessageBox.Show(
                    "All fields must be filled out.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            string query = "UPDATE Vehicle SET " +
               "[Year] = @Year, " +
               "[Model] = @Model, " +
               "[RegistrationNum] = @RegistrationNum, " +
               "[RegistrationExpiry] = @RegistrationExpiry, " +
               "[InsuranceExpiry] = @InsuranceExpiry, " +
               "[CurrentMileage] = @CurrentMileage, " +
               "[FuelType] = @FuelType " +
               "WHERE [UserID] = @UserID " +
               "AND [VehicleID] = @VehicleID";


            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            {
                using (SqlCommand command =
                       new SqlCommand(query, connection))
                {
                   
                    command.Parameters.AddWithValue("@Year", year);
                    command.Parameters.AddWithValue("@Model", model);
                    command.Parameters.AddWithValue("@RegistrationNum", registrationNum);
                    command.Parameters.AddWithValue("@RegistrationExpiry", dateTimePicker2.Value.Date);
                    command.Parameters.AddWithValue("@InsuranceExpiry", dateTimePicker3.Value.Date);
                    command.Parameters.AddWithValue("@CurrentMileage", currentMileage);
                    command.Parameters.AddWithValue("@FuelType", fuelType);



                    // These IDs are NOT changed
                    command.Parameters.AddWithValue("@UserID", userId);
                    command.Parameters.AddWithValue("@VehicleID", vehicleId);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show(
                            "Vehicle profile updated successfully!",
                            "Success",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(
                            "No record was updated.",
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }

                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
       "Are you sure you want to delete this vehicle profile?",
       "Confirm Deletion",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Warning
   );

            if (result == DialogResult.Yes)
            {
                string query = "DELETE FROM Vehicle " +
                               "WHERE VehicleID = @VehicleID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@VehicleID", vehicleId);

                        connection.Open();

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(
                                "Vehicle profile deleted successfully!",
                                "Success",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information
                            );

                            Close();
                        }
                        else
                        {
                            MessageBox.Show(
                                "No vehicle was found to delete.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error
                            );
                        }
                    }
                }
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f3 = new Form3(userId);
            f3.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
    
    
}