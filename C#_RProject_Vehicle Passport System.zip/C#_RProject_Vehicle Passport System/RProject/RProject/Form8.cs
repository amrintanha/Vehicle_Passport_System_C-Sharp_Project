using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace RProject
{
    public partial class Form8 : Form
    {
        string connectionString =
            "data source=DESKTOP-ELE0INQ\\SQLEXPRESS; database=V; integrated security=SSPI";

        int userId;

        public Form8(int userId)
        {
            InitializeComponent();

            this.userId = userId;

            txbTransferID.ReadOnly = true;
            txbFromUser.Text = userId.ToString();
            txbFromUser.ReadOnly = true;

            LoadVehicles();
            LoadUsers();
            LoadTransfers();
        }

        // =========================================================
        // Load the current user's own vehicles (only vehicles they
        // still own can be transferred)
        // =========================================================
        private void LoadVehicles()
        {
            string query = "SELECT VehicleID, RegistrationNum FROM Vehicle WHERE UserID = @UserID ORDER BY RegistrationNum";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@UserID", userId);

                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);

                cmbVehicle.DataSource = table;
                cmbVehicle.DisplayMember = "RegistrationNum";
                cmbVehicle.ValueMember = "VehicleID";
            }
        }

        // =========================================================
        // Load every other user into the "To user" combo box
        // =========================================================
        private void LoadUsers()
        {
            string query = "SELECT UserID, Username FROM users WHERE UserID <> @UserID ORDER BY Username";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@UserID", userId);

                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);

                cmbToUser.DataSource = table;
                cmbToUser.DisplayMember = "Username";
                cmbToUser.ValueMember = "UserID";
            }
        }

        // =========================================================
        // Load transfer history involving the current user
        // =========================================================
        private void LoadTransfers()
        {
            string query = @"
                SELECT
                    T.TransferID,
                    T.VehicleID,
                    V.RegistrationNum AS Vehicle,
                    T.FromUserID,
                    T.ToUserID,
                    T.TransferDate
                FROM Transfer T
                INNER JOIN Vehicle V ON T.VehicleID = V.VehicleID
                WHERE T.FromUserID = @UserID OR T.ToUserID = @UserID
                ORDER BY T.TransferID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@UserID", userId);

                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }

        // =========================================================
        // ADD (logs the transfer AND moves ownership - wrapped in
        // a transaction so both writes succeed or neither does)
        // =========================================================
        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbVehicle.SelectedValue == null)
            {
                MessageBox.Show("Please select a vehicle.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbToUser.SelectedValue == null)
            {
                MessageBox.Show("Please select a user to transfer to.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int vehicleId = Convert.ToInt32(cmbVehicle.SelectedValue);
            int toUserId = Convert.ToInt32(cmbToUser.SelectedValue);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    string insertQuery = @"
                        INSERT INTO Transfer (VehicleID, FromUserID, ToUserID, TransferDate)
                        VALUES (@VehicleID, @FromUserID, @ToUserID, @Date)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection, transaction);
                    insertCommand.Parameters.AddWithValue("@VehicleID", vehicleId);
                    insertCommand.Parameters.AddWithValue("@FromUserID", userId);
                    insertCommand.Parameters.AddWithValue("@ToUserID", toUserId);
                    insertCommand.Parameters.AddWithValue("@Date", dtpTransferDate.Value.Date);
                    insertCommand.ExecuteNonQuery();

                    string updateQuery = "UPDATE Vehicle SET UserID = @ToUserID WHERE VehicleID = @VehicleID";
                    SqlCommand updateCommand = new SqlCommand(updateQuery, connection, transaction);
                    updateCommand.Parameters.AddWithValue("@ToUserID", toUserId);
                    updateCommand.Parameters.AddWithValue("@VehicleID", vehicleId);
                    updateCommand.ExecuteNonQuery();

                    transaction.Commit();

                    MessageBox.Show("Vehicle transferred!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LoadVehicles();
                    LoadTransfers();
                    ClearFields();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show("Transfer failed:\n\n" + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // =========================================================
        // UPDATE (corrects the transfer date on an existing log
        // entry only - it does NOT move ownership again)
        // =========================================================
        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txbTransferID.Text))
            {
                MessageBox.Show("Please select a transfer record first.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "UPDATE Transfer SET TransferDate = @Date WHERE TransferID = @TransferID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Date", dtpTransferDate.Value.Date);
                command.Parameters.AddWithValue("@TransferID", Convert.ToInt32(txbTransferID.Text.Trim()));

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Transfer date updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadTransfers();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("No record was found to update.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        // =========================================================
        // DELETE (removes the log entry only - it does NOT
        // reverse ownership)
        // =========================================================
        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txbTransferID.Text))
            {
                MessageBox.Show("Please select a transfer record first.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show(
                "Delete this transfer record?\n\nThis only removes the log entry - it does NOT change current vehicle ownership.",
                "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result != DialogResult.Yes) return;

            string query = "DELETE FROM Transfer WHERE TransferID = @TransferID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@TransferID", Convert.ToInt32(txbTransferID.Text.Trim()));

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Transfer record deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadTransfers();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("No record was found to delete.", "Delete Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        // =========================================================
        // CLEAR
        // =========================================================
        private void button4_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            txbTransferID.Clear();
            dtpTransferDate.Value = DateTime.Now;
            if (cmbVehicle.Items.Count > 0) cmbVehicle.SelectedIndex = 0;
            if (cmbToUser.Items.Count > 0) cmbToUser.SelectedIndex = 0;
            dataGridView1.ClearSelection();
        }

        // =========================================================
        // SEARCH
        // =========================================================
        private void button5_Click(object sender, EventArgs e)
        {
            string searchValue = txbSearch.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show("Please enter a search term.", "Search", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = @"
                SELECT
                    T.TransferID,
                    T.VehicleID,
                    V.RegistrationNum AS Vehicle,
                    T.FromUserID,
                    T.ToUserID,
                    T.TransferDate
                FROM Transfer T
                INNER JOIN Vehicle V ON T.VehicleID = V.VehicleID
                WHERE (T.FromUserID = @UserID OR T.ToUserID = @UserID)
                  AND (CAST(T.TransferID AS NVARCHAR) LIKE @Search OR V.RegistrationNum LIKE @Search)
                ORDER BY T.TransferID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@UserID", userId);
                command.Parameters.AddWithValue("@Search", "%" + searchValue + "%");

                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;

                if (table.Rows.Count == 0)
                {
                    MessageBox.Show("No matching records found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        // =========================================================
        // SHOW ALL
        // =========================================================
        private void button6_Click(object sender, EventArgs e)
        {
            txbSearch.Clear();
            LoadTransfers();
        }

        // =========================================================
        // GRID ROW CLICK -> load into fields
        // =========================================================
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            if (row.Cells["TransferID"].Value != null)
                txbTransferID.Text = row.Cells["TransferID"].Value.ToString();

            if (row.Cells["VehicleID"].Value != null)
                cmbVehicle.SelectedValue = row.Cells["VehicleID"].Value;

            if (row.Cells["ToUserID"].Value != null)
                cmbToUser.SelectedValue = row.Cells["ToUserID"].Value;

            if (row.Cells["TransferDate"].Value != null && row.Cells["TransferDate"].Value != DBNull.Value)
                dtpTransferDate.Value = Convert.ToDateTime(row.Cells["TransferDate"].Value);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3(userId);
            f3.Show();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
      "Are you sure you want to exit the application?",
      "Confirm Exit",
      MessageBoxButtons.YesNo,
      MessageBoxIcon.Question
  );



            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }

        }
    }
}
