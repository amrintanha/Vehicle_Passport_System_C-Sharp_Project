﻿using RProject;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form7 : Form
    {
        // =========================================================
        // Database connection
        // =========================================================
        string connectionString = "data source=DESKTOP-ELE0INQ\\SQLEXPRESS; database=V; integrated security=SSPI";
        int userId;



        // =========================================================
        // for load the form
        // =========================================================

        public Form7(int userId)
        {
            InitializeComponent();

            this.userId = userId;

            // Record ID is generated automatically
            txbRecordID.ReadOnly = true;

            // Setup Accident ComboBox
            SetupAccidentComboBox();

            // Load vehicles from database
            LoadVehicles();

            // Load all maintenance records
            LoadMaintenance();
        }


        // =========================================================
        // Accident Combobox (for yes & no)
        // =========================================================

        private void SetupAccidentComboBox()
        {
            // Add Yes and No when they are not exist insidew the combobox
            if (!cmbAccident.Items.Contains("Yes"))
            {
                cmbAccident.Items.Add("Yes");
            }

            if (!cmbAccident.Items.Contains("No"))
            {
                cmbAccident.Items.Add("No");
            }


            // set default = No
            if (cmbAccident.Items.Count > 0)
            {
                cmbAccident.SelectedItem = "No";
            }
        }




        // =========================================================
        // Load Vehicle from database
        // =========================================================
        private void LoadVehicles()
        {
            string query = @"
        SELECT 
            VehicleID,
            RegistrationNum
        FROM Vehicle
        WHERE UserID = @UserID
        ORDER BY RegistrationNum";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userId);

                    try
                    {
                        connection.Open();

                        SqlDataReader reader = command.ExecuteReader();
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);

                        cmbVehicle.DataSource = dataTable;
                        cmbVehicle.DisplayMember = "RegistrationNum";
                        cmbVehicle.ValueMember = "VehicleID";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Error loading vehicles:\n\n" +
                            ex.Message,
                            "Database Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
            }
        }


       


        // =========================================================
        //for load all maintenance record
        // =========================================================

        private void LoadMaintenance()
        {
            string query = @"
                SELECT
                    Main.RecordID,
                    Main.VehicleID,
                    Vehicle.RegistrationNum AS Registration,
                    Main.[Date],
                    Main.Service,
                    Main.Cost,
                    Main.Accident
                FROM Main
                INNER JOIN Vehicle
                    ON Main.VehicleID = Vehicle.VehicleID
                ORDER BY Main.RecordID";


            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();

                        SqlDataReader reader =
                            command.ExecuteReader();

                        DataTable dataTable =
                            new DataTable();

                        dataTable.Load(reader);

                        dataGridView1.DataSource =
                            dataTable;

                        FormatDataGridView();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Error loading maintenance records:\n\n" +
                            ex.Message,
                            "Database Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
            }
        }


        // =========================================================
        // Format data grid view
        // =========================================================

        private void FormatDataGridView()
        {
            if (dataGridView1.Columns.Count == 0)
            {
                return;
            }

            dataGridView1.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dataGridView1.MultiSelect = false;

            dataGridView1.ReadOnly = true;

            dataGridView1.AllowUserToAddRows = false;

            dataGridView1.AllowUserToDeleteRows = false;

            dataGridView1.RowHeadersVisible = true;
        }


        // =========================================================
        // Generate next record id
        // =========================================================

        private string GenerateRecordID(SqlConnection connection)
        {
            string query = @"
                SELECT ISNULL(
                    MAX(TRY_CONVERT(INT, RecordID)),
                    0
                ) + 1
                FROM Main";


            using (SqlCommand command =
                new SqlCommand(query, connection))
            {
                object result =
                    command.ExecuteScalar();

                int nextID =
                    Convert.ToInt32(result);

                return nextID.ToString("D5");
            }
        }


        // =========================================================
        // ADD button
        // =========================================================

        private void button1_Click(object sender, EventArgs e)
        {
            // -------------------------
            // validation
            // -------------------------

            if (cmbVehicle.SelectedValue == null)
            {
                MessageBox.Show(
                    "Please select a vehicle.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (string.IsNullOrWhiteSpace(
                txbServiceName.Text))
            {
                MessageBox.Show(
                    "Please enter the service name.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txbServiceName.Focus();

                return;
            }


            if (string.IsNullOrWhiteSpace(
                txbCost.Text))
            {
                MessageBox.Show(
                    "Please enter the cost.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txbCost.Focus();

                return;
            }


            if (!float.TryParse(
                txbCost.Text.Trim(),
                out float cost))
            {
                MessageBox.Show(
                    "Cost must be a valid number.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txbCost.Focus();

                return;
            }


            if (cost < 0)
            {
                MessageBox.Show(
                    "Cost cannot be negative.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            // -------------------------
            // for insert
            // -------------------------

            string query = @"
                INSERT INTO Main
                (
                    RecordID,
                    VehicleID,
                    [Date],
                    Service,
                    Cost,
                    Accident
                )
                VALUES
                (
                    @RecordID,
                    @VehicleID,
                    @Date,
                    @Service,
                    @Cost,
                    @Accident
                )";


            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();


                    // Generate Record ID
                    string recordID =
                        GenerateRecordID(connection);


                    using (SqlCommand command =
                        new SqlCommand(query, connection))
                    {
                        command.Parameters.Add(
                            "@RecordID",
                            SqlDbType.NVarChar, 100)
                            .Value = recordID;

                        command.Parameters.Add(
                            "@VehicleID",
                            SqlDbType.NVarChar, 100)
                            .Value =
                            cmbVehicle.SelectedValue.ToString();

                        command.Parameters.Add(
                            "@Date",
                            SqlDbType.Date)
                            .Value =
                            dtpMaintenanceDate.Value.Date;

                        command.Parameters.Add(
                            "@Service",
                            SqlDbType.NVarChar, 100)
                            .Value =
                            txbServiceName.Text.Trim();

                        command.Parameters.Add(
                            "@Cost",
                            SqlDbType.Float)
                            .Value = cost;

                        command.Parameters.Add(
                            "@Accident",
                            SqlDbType.NVarChar, 100)
                            .Value =
                            cmbAccident.Text;


                        int rowsAffected =
                            command.ExecuteNonQuery();


                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(
                                "Maintenance record added successfully!\n\n" +
                                "Record ID: " + recordID,
                                "Success",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                            LoadMaintenance();

                            ClearFields();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Error adding maintenance record:\n\n" +
                        ex.Message,
                        "Database Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }


        // =========================================================
        // DATAGRIDVIEW CELL CLICK
        // =========================================================

        private void dataGridView1_CellClick(
    object sender,
    DataGridViewCellEventArgs e)
{
    if (e.RowIndex < 0)
    {
        return;
    }

    try
    {
        DataGridViewRow row =
            dataGridView1.Rows[e.RowIndex];

        // =========================
        // RECORD ID
        // =========================

        if (row.Cells["RecordID"].Value != null)
        {
            txbRecordID.Text =
                row.Cells["RecordID"].Value.ToString();
        }


        // =========================
        // VEHICLE
        // =========================

        if (row.Cells["VehicleID"].Value != null)
        {
            string vehicleID =
                row.Cells["VehicleID"].Value.ToString();

            cmbVehicle.SelectedValue = vehicleID;
        }


        // =========================
        // DATE
        // =========================

        if (row.Cells["Date"].Value != null &&
            row.Cells["Date"].Value != DBNull.Value)
        {
            dtpMaintenanceDate.Value =
                Convert.ToDateTime(
                    row.Cells["Date"].Value);
        }


        // =========================
        // SERVICE
        // =========================

        if (row.Cells["Service"].Value != null &&
            row.Cells["Service"].Value != DBNull.Value)
        {
            txbServiceName.Text =
                row.Cells["Service"].Value.ToString();
        }
        else
        {
            txbServiceName.Clear();
        }


        // =========================
        // COST
        // =========================

        if (row.Cells["Cost"].Value != null &&
            row.Cells["Cost"].Value != DBNull.Value)
        {
            txbCost.Text =
                row.Cells["Cost"].Value.ToString();
        }
        else
        {
            txbCost.Clear();
        }


        // =========================
        // ACCIDENT
        // =========================

        if (row.Cells["Accident"].Value != null &&
            row.Cells["Accident"].Value != DBNull.Value)
        {
            cmbAccident.Text =
                row.Cells["Accident"].Value.ToString();
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show(
            "Error selecting record:\n\n" +
            ex.Message,
            "Error",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
}


        // =========================================================
        // UPDATE BUTTON
        // =========================================================

        private void button2_Click(object sender, EventArgs e)
        {
            // -------------------------
            // VALIDATION
            // -------------------------

            if (string.IsNullOrWhiteSpace(
                txbRecordID.Text))
            {
                MessageBox.Show(
                    "Please select a maintenance record first.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (cmbVehicle.SelectedValue == null)
            {
                MessageBox.Show(
                    "Please select a vehicle.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (string.IsNullOrWhiteSpace(
                txbServiceName.Text))
            {
                MessageBox.Show(
                    "Please enter the service name.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (!float.TryParse(
                txbCost.Text.Trim(),
                out float cost))
            {
                MessageBox.Show(
                    "Cost must be a valid number.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            // -------------------------
            // UPDATE
            // -------------------------

            string query = @"
                UPDATE Main
                SET
                    VehicleID = @VehicleID,
                    [Date] = @Date,
                    Service = @Service,
                    Cost = @Cost,
                    Accident = @Accident
                WHERE RecordID = @RecordID";


            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.Add(
                        "@RecordID",
                        SqlDbType.NVarChar, 100)
                        .Value =
                        txbRecordID.Text.Trim();

                    command.Parameters.Add(
                        "@VehicleID",
                        SqlDbType.NVarChar, 100)
                        .Value =
                        cmbVehicle.SelectedValue.ToString();

                    command.Parameters.Add(
                        "@Date",
                        SqlDbType.Date)
                        .Value =
                        dtpMaintenanceDate.Value.Date;

                    command.Parameters.Add(
                        "@Service",
                        SqlDbType.NVarChar, 100)
                        .Value =
                        txbServiceName.Text.Trim();

                    command.Parameters.Add(
                        "@Cost",
                        SqlDbType.Float)
                        .Value = cost;

                    command.Parameters.Add(
                        "@Accident",
                        SqlDbType.NVarChar, 100)
                        .Value =
                        cmbAccident.Text;


                    try
                    {
                        connection.Open();

                        int rowsAffected =
                            command.ExecuteNonQuery();


                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(
                                "Maintenance record updated successfully!",
                                "Success",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                            LoadMaintenance();

                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show(
                                "No record was found to update.",
                                "Update Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Error updating maintenance record:\n\n" +
                            ex.Message,
                            "Database Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
            }
        }


        // =========================================================
        // DELETE BUTTON
        // =========================================================

        private void button3_Click(object sender, EventArgs e)
        {
            // -------------------------
            // VALIDATION
            // -------------------------

            if (string.IsNullOrWhiteSpace(
                txbRecordID.Text))
            {
                MessageBox.Show(
                    "Please select a maintenance record first.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            // -------------------------
            // CONFIRM DELETE
            // -------------------------

            DialogResult result =
                MessageBox.Show(
                    "Are you sure you want to delete this maintenance record?\n\n" +
                    "Record ID: " + txbRecordID.Text,
                    "Confirm Deletion",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);


            if (result != DialogResult.Yes)
            {
                return;
            }


            // -------------------------
            // DELETE
            // -------------------------

            string query = @"
                DELETE FROM Main
                WHERE RecordID = @RecordID";


            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.Add(
                        "@RecordID",
                        SqlDbType.NVarChar, 100)
                        .Value =
                        txbRecordID.Text.Trim();


                    try
                    {
                        connection.Open();

                        int rowsAffected =
                            command.ExecuteNonQuery();


                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(
                                "Maintenance record deleted successfully!",
                                "Success",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                            LoadMaintenance();

                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show(
                                "No record was found to delete.",
                                "Delete Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Error deleting maintenance record:\n\n" +
                            ex.Message,
                            "Database Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
            }
        }


        // =========================================================
        // CLEAR BUTTON
        // =========================================================

        private void button4_Click(object sender, EventArgs e)
        {
            ClearFields();
        }


        // =========================================================
        // CLEAR FIELDS
        // =========================================================

        private void ClearFields()
        {
            // Clear Record ID
            txbRecordID.Clear();

            // Clear Service
            txbServiceName.Clear();

            // Clear Cost
            txbCost.Clear();

            // Reset date
            dtpMaintenanceDate.Value =
                DateTime.Now;


            // Reset Accident
            if (cmbAccident.Items.Count > 0)
            {
                cmbAccident.SelectedItem = "No";
            }


            // Reset Vehicle
            if (cmbVehicle.Items.Count > 0)
            {
                cmbVehicle.SelectedIndex = 0;
            }


            // Remove DataGridView selection
            dataGridView1.ClearSelection();
        }


        // =========================================================
        // SEARCH BUTTON
        // =========================================================

        private void button5_Click(object sender, EventArgs e)
        {
            string searchValue =
                txbSearch.Text.Trim();


            if (string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show(
                    "Please enter a search term.",
                    "Search",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txbSearch.Focus();

                return;
            }


            string query = @"
                SELECT
                    Main.RecordID,
                    Main.VehicleID,
                    Vehicle.RegistrationNum AS Registration,
                    Main.[Date],
                    Main.Service,
                    Main.Cost,
                    Main.Accident
                FROM Main
                INNER JOIN Vehicle
                    ON Main.VehicleID = Vehicle.VehicleID
                WHERE
                    Main.RecordID LIKE @Search
                    OR Main.VehicleID LIKE @Search
                    OR Vehicle.RegistrationNum LIKE @Search
                    OR Main.Service LIKE @Search
                    OR Main.Accident LIKE @Search
                ORDER BY Main.RecordID";


            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.Add(
                        "@Search",
                        SqlDbType.NVarChar, 100)
                        .Value =
                        "%" + searchValue + "%";


                    try
                    {
                        connection.Open();

                        SqlDataReader reader =
                            command.ExecuteReader();

                        DataTable dataTable =
                            new DataTable();

                        dataTable.Load(reader);

                        dataGridView1.DataSource =
                            dataTable;

                        FormatDataGridView();


                        if (dataTable.Rows.Count == 0)
                        {
                            MessageBox.Show(
                                "No matching records found.",
                                "Search Result",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            "Search error:\n\n" +
                            ex.Message,
                            "Database Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    }
                }
            }
        }


        // =========================================================
        // SHOW ALL BUTTON
        // =========================================================

        private void button6_Click(object sender, EventArgs e)
        {
            txbSearch.Clear();

            LoadMaintenance();

            dataGridView1.ClearSelection();
        }


        // =========================================================
        // FORM LOAD EVENT
        // =========================================================

        private void Form1_Load(object sender, EventArgs e)
        {
            // Nothing required here.
            // Data is loaded in the constructor.
        }



        // =========================================================
        // OLD DESIGNER EVENTS
        // =========================================================

        private void label6_Click(object sender, EventArgs e)
        {
            // No action required
        }

        private void cmbAccident_SelectedIndexChanged(object sender, EventArgs e)
        {
            // No action required
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
       "Are you sure you want to exit the application?",
       "Confirm Exit",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Question
   );



            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }



        }

        private void cmbVehicle_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3(userId);
            f3.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}