﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RProject
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        string connectionString = "data source=DESKTOP-ELE0INQ\\SQLEXPRESS; database=V; integrated security=SSPI";
        int id;

        public Form4(int i)
        {
            id = i;
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int year = dateTimePicker1.Value.Year;
            string model = textBox1.Text.Trim();
            string registrationNum = textBox2.Text.Trim();
            string mileageText = textBox5.Text.Trim();
            string fuelType = comboBox1.Text.Trim();

            
            if (string.IsNullOrWhiteSpace(model) ||
                string.IsNullOrWhiteSpace(registrationNum) ||
                string.IsNullOrWhiteSpace(mileageText) ||
                string.IsNullOrWhiteSpace(fuelType))
            {
                MessageBox.Show(
                    "All fields must be filled out.",
                    "Validation Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            
            if (!int.TryParse(mileageText, out int currentMileage))
            {
                MessageBox.Show(
                    "Please enter a valid mileage.",
                    "Invalid Mileage",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            string query = "INSERT INTO Vehicle " +
                "(UserID, Year, Model, RegistrationNum, RegistrationExpiry, InsuranceExpiry, CurrentMileage, FuelType) " +
                "VALUES (@UserID, @Year, @Model, @RegistrationNum, @RegistrationExpiry, @InsuranceExpiry, @CurrentMileage, @FuelType)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", id);
                    command.Parameters.AddWithValue("@Year", year);
                    command.Parameters.AddWithValue("@Model", model);
                    command.Parameters.AddWithValue("@RegistrationNum", registrationNum);
                    command.Parameters.AddWithValue("@RegistrationExpiry", dateTimePicker1.Value.Date);
                    command.Parameters.AddWithValue("@InsuranceExpiry", dateTimePicker2.Value.Date);
                    command.Parameters.AddWithValue("@CurrentMileage", currentMileage);
                    command.Parameters.AddWithValue("@FuelType", fuelType);

                    connection.Open();

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Vehicle information added successfully.",
                                        "Success",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);

                        this.Hide();

                        Form3 f3 = new Form3(id);
                        f3.Show();
                    }
                    else
                    {
                        MessageBox.Show("Vehicle information was not added.",
                                        "Error",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            
        }
        }


        

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f3 = new Form3(id);
            f3.Show();
        }
    }
}
