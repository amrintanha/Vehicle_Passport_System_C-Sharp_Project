﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp3;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RProject
{
    public partial class Form3 : Form
    {
        string connectionString = "data source=DESKTOP-ELE0INQ\\SQLEXPRESS; database=V; integrated security=SSPI";
        int id;
        int vehicleId;

        public Form3()
        {
            InitializeComponent();
        }

        public Form3(int i)
        {
            id = i;
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

            string query = @"SELECT VehicleID, UserID, Year, Model, RegistrationNum,
                            RegistrationExpiry, InsuranceExpiry,
                            CurrentMileage, FuelType
                     FROM Vehicle
                     WHERE UserID = @UserID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", id);

                    connection.Open();

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();

                    adapter.Fill(table);

                    if (table.Rows.Count == 0)
                    {
                        dataGridView1.DataSource = null;

                        MessageBox.Show(
                            "No vehicle yet? Add your first vehicle.",
                            "No Vehicle",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else
                    {
                        dataGridView1.DataSource = table;
                    }
                }
            }
        }

                         
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                vehicleId = Convert.ToInt32(
                    dataGridView1.Rows[e.RowIndex].Cells["VehicleID"].Value
                );
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4(id);
            f4.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string searchValue = textBox1.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show("Please enter a search term.",
                                "Validation Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            string query = @"SELECT VehicleID, UserID, Year, Model, RegistrationNum,
                        RegistrationExpiry, InsuranceExpiry,
                        CurrentMileage, FuelType
                 FROM Vehicle
                 WHERE UserID = @UserID
                 AND (
                     CAST(VehicleID AS NVARCHAR) LIKE @searchTerm
                     OR CAST(Year AS NVARCHAR) LIKE @searchTerm
                     OR Model LIKE @searchTerm
                     OR RegistrationNum LIKE @searchTerm
                     OR CAST(RegistrationExpiry AS NVARCHAR) LIKE @searchTerm
                     OR CAST(InsuranceExpiry AS NVARCHAR) LIKE @searchTerm
                     OR CAST(CurrentMileage AS NVARCHAR) LIKE @searchTerm
                     OR CAST(FuelType AS NVARCHAR) LIKE @searchTerm
                 )";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", id);
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchValue + "%");

                    connection.Open();

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    dataGridView1.DataSource = table;

                    if (table.Rows.Count == 0)
                    {
                        MessageBox.Show("No matching vehicles found.",
                                        "Search Result",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form f4 = new Form4(id);
            f4.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show(
                    "Please select a vehicle first.",
                    "No Selection",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

           
            int selectedVehicleId = Convert.ToInt32(
                selectedRow.Cells["VehicleID"].Value
            );

            
            int selectedUserId = Convert.ToInt32(
                selectedRow.Cells["UserID"].Value
            );

            
            this.Hide();
            Form5 f5 = new Form5(selectedUserId, selectedVehicleId);
            f5.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form7 f7 = new Form7(id);
            f7.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form8 f8 = new Form8(id);
            f8.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 f1 = new Form1();
            f1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
       "Are you sure you want to exit the application?",
       "Confirm Exit",
       MessageBoxButtons.YesNo,
       MessageBoxIcon.Question
   );



            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }

        }
    }
}
