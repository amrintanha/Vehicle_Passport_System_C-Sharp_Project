-- =========================================================
-- OwnershipTransfer table for the "V" database
-- Matches this project's existing style: plain auto-increment
-- integer IDs (like Vehicle.VehicleID), not the string-ID
-- scheme from the other version of this form.
-- =========================================================

USE V;
GO

IF OBJECT_ID('dbo.OwnershipTransfer', 'U') IS NOT NULL DROP TABLE dbo.OwnershipTransfer;
GO

CREATE TABLE OwnershipTransfer (
    TransferID    INT IDENTITY(1,1) PRIMARY KEY,
    VehicleID     INT NOT NULL,
    FromUserID    INT NOT NULL,
    ToUserID      INT NOT NULL,
    TransferDate  DATE NOT NULL,
    CONSTRAINT FK_Transfer_Vehicle  FOREIGN KEY (VehicleID)  REFERENCES Vehicle(VehicleID) ON DELETE CASCADE,
    CONSTRAINT FK_Transfer_FromUser FOREIGN KEY (FromUserID) REFERENCES users(UserID),
    CONSTRAINT FK_Transfer_ToUser   FOREIGN KEY (ToUserID)   REFERENCES users(UserID)
);
GO

SELECT name FROM sys.tables ORDER BY name;
